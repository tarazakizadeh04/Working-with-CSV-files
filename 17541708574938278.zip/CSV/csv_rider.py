import csv 



def read_csv(path):
    with open(path,newline='') as filee:
        reader=csv.DictReader(filee)
        data_list=list(reader)
    return data_list


def calculate(csv_data):
    result=[]
    for i in csv_data:
        number=int(i['Quantity'])
        price=int(i['Price'])
        total=number*price
        result.append({
            'Product Name': i['Product Name'],
            'number': number,
            'total Quantity': total
        })
    return(result)

def save_csv(path,data):
    fieldnames = ['Product Name', 'number', 'total Quantity']
    with open(path, "w",newline='') as file:
        writer=csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for j in data:
            writer.writerow(j)


csv_data=read_csv(r"T:\VS_project\CSV\1741502118270796.csv")

first_variable=calculate(csv_data)
file_path=r'T:\VS_project\CSV\final_file.csv'
save_csv(file_path,first_variable)
print(f'final csv file saved in {file_path}')
